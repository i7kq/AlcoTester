//
//  NSMenuItemCustom.swift
//  AlcoCalc
//
//  Created by Anton on 08.12.2021.
//

import Cocoa

class NSMenuItemCustom: NSMenuItem
{
    @IBInspectable var imageName:String = ""
    @IBInspectable var alcohol:Float = 0
}
