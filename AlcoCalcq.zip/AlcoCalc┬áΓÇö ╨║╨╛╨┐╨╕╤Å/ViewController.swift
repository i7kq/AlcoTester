//
//  ViewController.swift
//  Alcotester
//
//  Created by Anton on 07.12.2021.
//

import Cocoa

class ViewController: NSViewController {
    @IBOutlet weak var ageFiled: NSTextField!
    @IBOutlet weak var weightField: NSTextField!
    @IBOutlet weak var resultField: NSTextField!
    @IBOutlet weak var processButton: NSButton!
    @IBOutlet weak var sexSelect: NSPopUpButton!
    @IBOutlet weak var alcoSelect: NSPopUpButton!
    @IBOutlet weak var volumeField: NSTextField!
    @IBOutlet weak var alcogolCustomField: NSTextField!
    @IBOutlet weak var timeDriveField: NSTextField!
    @IBOutlet var imageAlcoView: NSImageView!
    
    
    var alcohol:Float = 0
    let k:Float = 0.789
    var sex:Float = 0
    var volume:Float = 0
    var weight:Float = 0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        setDefaults()
    }

    override var representedObject: Any? {
        didSet {
        // Update the view, if already loaded.
        }
    }
    
    /**
     Set defaults
     */
    private func setDefaults() -> Void
    {
        alcogolCustomField.isHidden = true
        resultField.stringValue = ""
        timeDriveField.isHidden = true
        
        // Set default image
        let item = alcoSelect.selectedItem! as! NSMenuItemCustom
        imageAlcoView.image = NSImage(named: item.imageName)
        
    }
    
    /**
     Calculation
     */
    @IBAction func calculate(_ sender: Any) {
        volume = volumeField.floatValue
        weight = weightField.floatValue
        
        let alcoholItem = alcoSelect.selectedItem as! NSMenuItemCustom
        alcohol = alcoholItem.alcohol == 0 ? alcogolCustomField.floatValue : alcoholItem.alcohol
        sex = Float((sexSelect.selectedItem?.identifier!.rawValue)!)!
        
        if validator() == false {return}
        
        let datetime = minutesToHoursMinutesSeconds(
            Int(
                volume / 1000 * alcohol * k * 10 / (weightField.floatValue * sex) / 0.15 * 60
            )
        )
        
        resultField.stringValue = "\(datetime.0)h \(datetime.1)m"
        timeDriveField.isHidden = false
    }
    
    /**
     Validator
     */
    func validator() -> Bool
    {
        if alcohol == 0.0 || volume == 0.0 || weight == 0.0 {
            return false
        }
        
        return true
    }
    
    /**
     Minutes to datetime
     */
    func minutesToHoursMinutesSeconds(_ minutes: Int) -> (Int, Int) {
        return (minutes / 60, (minutes % 60))
    }
    
    /**
     Alco select changes
     */
    @IBAction func alcoSelectChanges(_ sender: Any) -> Void
    {
        if alcoSelect.indexOfSelectedItem == alcoSelect.index(of: alcoSelect.lastItem!) {
            alcogolCustomField.stringValue = ""
            alcogolCustomField.isHidden = false
        } else {
            alcogolCustomField.isHidden = true
        }
        
        let item = alcoSelect.selectedItem as! NSMenuItemCustom
        imageAlcoView.image = NSImage(named: item.imageName)
        
        calculate("")
    }
    
    /**
     Sex changes
     */
    @IBAction func sexChanges(_ sender: Any) -> Void
    {
        calculate("")
    }
}
